/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putaddr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ahhammad <ahhammad@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/17 09:20:34 by ahhammad          #+#    #+#             */
/*   Updated: 2025/09/17 14:22:34 by ahhammad         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_putaddr(void *p)
{
	int				count;
	unsigned long	addr;

	if (!p)
	{
		ft_putstr("(nil)");
		return (5);
	}
	addr = (unsigned long)p;
	printf("\naddress %ld\n",addr);
	count = 2;
	write(1, "0x", 2);
	ft_convert_to_hexa(addr, 39, &count);
	return (count);
}
