
#include "./print/ft_printf.h"

int	main(void)
{
	int		i;
	char	*p;

	// Write C code here
	p = malloc(2);
	p[0] = '1';
	p[1] = '\0';
	// // ft_printf("%d  %s %c %p",100,"aahmad",'a',&p);
	// ft_printf("%c %s %d %u\n %p  %% \n",'a',"ahmad",100,-214748348,&p);
	// printf("\n%c %s %d %u\n %p %% \n",'a',"ahmad",100,-214748348,&p);
	int j;
	j = ft_printf(" %p %p\n",LONG_MAX);
	//i = printf(" %p %p\n ", LONG_MIN, LONG_MAX);
	// uintptr_t addr = (uintptr_t)p;
	//printf("ft_pr %d\n print %d \n",j, i);
	// printf("\n\n%ld",(uintptr_t)p);
	return (0);
}